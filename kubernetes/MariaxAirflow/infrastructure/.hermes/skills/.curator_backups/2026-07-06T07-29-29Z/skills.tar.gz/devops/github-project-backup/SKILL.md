---
name: github-project-backup
description: Strategy for backing up specific project files and AI agent persistence to GitHub while minimizing repository size and avoiding noise.
---

# GitHub Project Backup & Agent Persistence

This skill governs the process of selectively backing up a working directory to GitHub, ensuring that only essential configuration files, documentation, and AI agent state (knowledge/memory) are preserved.

## Trigger Conditions
- User wants to push a project to GitHub but is concerned about "memory" (storage/repo size).
- Need to backup an AI agent's learned experience (skills, memories, state) to allow restoration on another machine.
- Project contains heavy directories (node_modules, venv, .cache, logs) that must be excluded.

## Procedural Workflow

### 1. Analysis & Filtering
- **Identify Noise:** Scan the directory for hidden folders (`.*`) and known heavy directories (`venv`, `__pycache__`, `logs`).
- **Identify Core Assets:**
    - Configs: `.yaml`, `.yml`, `.json`.
    - Logic: `.py`, `.sh`, `.bash`.
    - Docs: `.md`.
- **Identify Agent State:** Specifically target the agent's persistence layer (e.g., `.hermes/skills/`, `.hermes/memories/`, `.hermes/state.db`).

### 2. Exclusion Setup (.gitignore)
Create a `.gitignore` that targets categories of noise rather than individual files:
- System/IDE noise (`.vscode-server/`, `.copilot/`, `__pycache__/`).
- Python environments (`venv/`).
- Agent transient data (`.hermes/logs/`, `.hermes/cache/`, `state.db-wal`).
- Application logs (`**/logs/`, `*.log`).

### 3. Selective Staging
Instead of `git add .` (which can time out or include unwanted files in large directories), use targeted additions:
- `git add .gitignore`
- `git add path/to/agent/persistence/`
- `git add "*.yml" "*.yaml" "*.md" "*.sh" "*.py"`
- `git add project_folder1/ project_folder2/`

### 4. Commit and Push
- Commit with a descriptive message (e.g., "Backup: [Project Name] and Agent Knowledge").
- Push to the remote origin.

## Pitfalls & Lessons
- **The `git add .` Timeout:** In environments with massive hidden caches (e.g., `.npm`, `.cache`), `git add .` may timeout. Always prioritize selective `git add` for targeted backups.
- **Agent State Recovery:** To successfully migrate an agent's "mind," you must save the skills and memories folders AND the primary state database (`state.db`), but exclude the write-ahead logs (`-wal`) and shared memory files (`-shm`) as they are transient.
- **Authentication Failures (HTTP vs SSH):** If `git push` fails with `fatal: could not read Username`, it's usually due to a missing or expired Personal Access Token (PAT) when using HTTPS. 
    - *Fix 1 (Manual):* Use a PAT as the password or embed it in the URL: `https://<TOKEN>@github.com/user/repo.git`.
    - *Fix 2 (Modern):* Use the GitHub CLI (`gh auth login`) to automate credential management via OAuth. This is the preferred method for AI agents to maintain stable connectivity.

## Verification
- Run `git status` after staging to verify no "noise" files (like venv or logs) were accidentally tracked.
- Confirm the presence of key persistence files in the commit.
